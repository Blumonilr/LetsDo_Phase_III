建立者：钱宇辰、靳炳淑

public boolean creatProject(Project project, MultipartFile dataSet);

public boolean validateProject(String publisherId,String projectId);//新建项目时检查项目名是否合法

public List<Project> searchProjects(String publisherId,String keyword);//根据keyword查找已有的项目，支持模糊查询

public List<String> viewPushEvents(String publisherId,String projectId);//查看某个项目的提交记录

public byte[] downloadTags(String publisherId,String projectId);//下载所有标注

public boolean pay(int money);//充值

Project{

  start time,end time

  String tagRequirement(JSON对象变成的String，包括要求描述和标注种类)

  publisherId,projectId(必须输入，否则无法上传)

  int money

  maxWorkerNum,currWorkerNum,packageNum//最大工作人数、当前工作人数、分包数

  proceeding//进度

  String workerRequirement(JSON对象变成的String，预期的限制有worker等级、准确率)
}

还要定义User、Publisher、Worker类，User作为基类
