WorkerService interface

QYC,JBS

List<String>viewAllProjects();//查看所有项目

Project getAProject(String projectId);//根据projectId获取Project对象

? forkProject(String workerId,String projectId);//fork项目，返回值待定

List<String>viewMyProjects(String workerId);//查看某个用户参加的项目名称

int viewProgress(String workerId,String projectId);//查看某个用户某个项目的进度

List<String>viewUndoData(String workerId,String projectId);

List<String>viewDoneData(String workerId,String projectId);

byte[]getAData(String workerId,String projectId,String dataId);

Tag getATag(String workerId,String projectId,String tagId);

boolean uploadTag(String userId,String projectId,String tagId,Tag tag);

boolean push(String workerId,String projectId);



Tag对象{
  String type
  Map<String,String>tags
  byte[]data
  int width,height
}

Data对象{
  byte[]data//图片本身
  int width，height//图片的长、宽
}
