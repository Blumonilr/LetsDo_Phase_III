project service
===================
1. find & search & view

view all projects by "" worker
view some projects by string
view a project by id
view one's projects

view project progress

find by : finish state

validate project by : finish state name

2. add

add new project

3. delete

4. modify

5. change state

initialize
open
close
