部署文档
===
YingYingMonster

钱宇辰  靳炳淑  王一博  吴林漾

0. 环境搭建
        Windows
        mysql5.7+
        jdk8
        python3.6
        maven3+

1. 获取源代码

        git clone git@114.215.188.21:161250103_YingYingMonster/LetsDo_Phase_III.git

2. 构建项目
        Windows环境：
          1. 在数据库中创建名为letsDo的数据库
          2. 进入项目根目录，打开命令行，输入 mvn package -DskipTests=true
          3. 进入根目录下target文件夹，把生成的LetsDo_Phase_III-0.0.1-SNAPSHOT.jar拷贝至想要运行的地方，例如C:/letsdo
          4. 将项目根目录下的Integrater文件夹、TextNodeTree文件、startjava.bat文件和startpy.bat文件拷贝至刚刚创建的C:/letsdo文件夹下，并且创建新的文件夹C:/letsdo/projectOverview
          5. 把src/main/resources/application-dev.yml文件拷贝至C:/letsdo文件夹下，和jar包位于同一路径
          6. application-dev.yml文件中的username和password选项修改为本地数据库的用户名和密码，其他属性按需修改

3. 启动项目
        Windows环境：
          1. 运行startjava.bat文件和startpy.bat
          2. 打开网页http://localhost:8081/进入项目主页

4. 服务端
        访问我们的服务器：http://120.79.205.168/8081/
